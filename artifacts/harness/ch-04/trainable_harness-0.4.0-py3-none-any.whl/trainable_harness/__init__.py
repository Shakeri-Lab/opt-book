"""Diagnostic harness for *Deep Learning: Making It Trainable*."""

from .precision import (
    QuantizationResult,
    UpdateTrace,
    float_contract,
    local_spacing,
    repeated_update,
    stochastic_update_trials,
    symmetric_quantize,
)
from .optimization import (
    NoisyQuadraticSummary,
    QuadraticTrace,
    classify_mode_factors,
    quadratic_spectrum,
    quadratic_trace,
    scalar_noisy_quadratic_trials,
)
from .streaming import (
    MomentState,
    comparison_audit,
    merge_moments,
    naive_moments,
    observation_ledger,
    stable_online_moments,
)

__all__ = [
    "MomentState",
    "NoisyQuadraticSummary",
    "QuantizationResult",
    "QuadraticTrace",
    "UpdateTrace",
    "comparison_audit",
    "classify_mode_factors",
    "float_contract",
    "local_spacing",
    "merge_moments",
    "naive_moments",
    "observation_ledger",
    "quadratic_spectrum",
    "quadratic_trace",
    "repeated_update",
    "stable_online_moments",
    "scalar_noisy_quadratic_trials",
    "stochastic_update_trials",
    "symmetric_quantize",
]

__version__ = "0.4.0"
