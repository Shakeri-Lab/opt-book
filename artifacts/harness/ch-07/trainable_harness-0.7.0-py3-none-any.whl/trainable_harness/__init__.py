"""Diagnostic harness for *Deep Learning: Making It Trainable*."""

from .precision import (
    QuantizationResult,
    UpdateTrace,
    float_contract,
    local_spacing,
    repeated_update,
    stochastic_update_trials,
    symmetric_quantize,
)
from .optimization import (
    NoisyQuadraticSummary,
    QuadraticTrace,
    classify_mode_factors,
    quadratic_spectrum,
    quadratic_trace,
    scalar_noisy_quadratic_trials,
)
from .geometry import (
    circle_covering_radius,
    circle_epsilon_net,
    operator_net_certificate,
    operator_net_estimate,
    sphere_cover_log_upper,
    uniform_subgaussian_threshold,
)
from .probability import (
    bernstein_two_regime_rate,
    centered_chi_square_log_mgf,
    centered_chi_square_sum_trials,
    centered_chi_square_sum_upper_tail,
    centered_chi_square_upper_tail,
    centered_pareto_clip_bias,
    empirical_tail_profile,
    moment_growth_profile,
    rademacher_projection_trials,
    standard_normal_maxima,
    subgaussian_max_threshold,
)
from .streaming import (
    MomentState,
    comparison_audit,
    merge_moments,
    naive_moments,
    observation_ledger,
    stable_online_moments,
)

__all__ = [
    "MomentState",
    "NoisyQuadraticSummary",
    "QuantizationResult",
    "QuadraticTrace",
    "UpdateTrace",
    "bernstein_two_regime_rate",
    "centered_chi_square_log_mgf",
    "centered_chi_square_sum_trials",
    "centered_chi_square_sum_upper_tail",
    "centered_chi_square_upper_tail",
    "centered_pareto_clip_bias",
    "circle_covering_radius",
    "circle_epsilon_net",
    "comparison_audit",
    "classify_mode_factors",
    "empirical_tail_profile",
    "float_contract",
    "local_spacing",
    "merge_moments",
    "moment_growth_profile",
    "naive_moments",
    "observation_ledger",
    "operator_net_certificate",
    "operator_net_estimate",
    "quadratic_spectrum",
    "quadratic_trace",
    "rademacher_projection_trials",
    "repeated_update",
    "stable_online_moments",
    "scalar_noisy_quadratic_trials",
    "sphere_cover_log_upper",
    "standard_normal_maxima",
    "stochastic_update_trials",
    "symmetric_quantize",
    "uniform_subgaussian_threshold",
    "subgaussian_max_threshold",
]

__version__ = "0.7.0"
