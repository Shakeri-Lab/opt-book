"""Random-operator diagnostics introduced with C08."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class SpectrumSummary:
    """Exact small-matrix singular-value diagnostics."""

    rows: int
    columns: int
    singular_values: tuple[float, ...]
    sigma_max: float
    sigma_min: float
    frobenius_norm: float
    condition_number: float
    mean_squared_stretch: float


@dataclass(frozen=True)
class PowerIterationResult:
    """One-sided spectral-norm estimates and the final input direction."""

    estimates: tuple[float, ...]
    vector: tuple[float, ...]


def _matrix(values: Iterable[Iterable[float]]) -> np.ndarray:
    resolved = np.asarray(tuple(tuple(row) for row in values), dtype=np.float64)
    if resolved.ndim != 2 or min(resolved.shape) < 1:
        raise ValueError("matrix must be nonempty and two-dimensional")
    if resolved.shape[0] < resolved.shape[1]:
        raise ValueError("the declared input-space lower edge requires rows >= columns")
    return resolved


def matrix_spectrum_summary(
    matrix: Iterable[Iterable[float]],
) -> SpectrumSummary:
    """Return an exact SVD summary for a square or tall real matrix."""

    resolved = _matrix(matrix)
    singular_values = np.linalg.svd(resolved, compute_uv=False)
    largest = float(singular_values[0])
    smallest = float(singular_values[-1])
    frobenius = float(np.linalg.norm(resolved, ord="fro"))
    condition = float(np.inf if smallest == 0.0 else largest / smallest)
    return SpectrumSummary(
        rows=int(resolved.shape[0]),
        columns=int(resolved.shape[1]),
        singular_values=tuple(float(value) for value in singular_values),
        sigma_max=largest,
        sigma_min=smallest,
        frobenius_norm=frobenius,
        condition_number=condition,
        mean_squared_stretch=float(frobenius**2 / resolved.shape[1]),
    )


def gaussian_singular_value_trials(
    rows: int,
    columns: int,
    *,
    trials: int,
    seed: int,
    scaled: bool = True,
) -> dict[str, np.ndarray]:
    """Sample Gaussian matrices and return exact edge and fixed-direction diagnostics."""

    if rows < columns or columns < 1:
        raise ValueError("dimensions must satisfy rows >= columns >= 1")
    if trials < 1:
        raise ValueError("trials must be positive")
    rng = np.random.default_rng(seed)
    normalizer = np.sqrt(rows) if scaled else 1.0
    largest = np.empty(trials, dtype=np.float64)
    smallest = np.empty(trials, dtype=np.float64)
    mean_squared = np.empty(trials, dtype=np.float64)
    fixed_stretch = np.empty(trials, dtype=np.float64)
    for index in range(trials):
        matrix = rng.standard_normal((rows, columns)) / normalizer
        singular_values = np.linalg.svd(matrix, compute_uv=False)
        largest[index] = singular_values[0]
        smallest[index] = singular_values[-1]
        mean_squared[index] = np.sum(matrix * matrix) / columns
        fixed_stretch[index] = np.linalg.norm(matrix[:, 0])
    return {
        "sigma_max": largest,
        "sigma_min": smallest,
        "mean_squared_stretch": mean_squared,
        "fixed_direction_stretch": fixed_stretch,
    }


def power_iteration_spectral_norm(
    matrix: Iterable[Iterable[float]],
    *,
    iterations: int,
    seed: int,
) -> PowerIterationResult:
    """Estimate only the largest singular value through power iteration on A.T @ A."""

    resolved = _matrix(matrix)
    if iterations < 1:
        raise ValueError("iterations must be positive")
    rng = np.random.default_rng(seed)
    vector = rng.standard_normal(resolved.shape[1])
    vector /= np.linalg.norm(vector)
    estimates = []
    for _ in range(iterations):
        image = resolved @ vector
        estimates.append(float(np.linalg.norm(image)))
        pullback = resolved.T @ image
        norm = float(np.linalg.norm(pullback))
        if norm == 0.0:
            raise ValueError("power iteration is undefined for the zero map")
        vector = pullback / norm
    return PowerIterationResult(
        estimates=tuple(estimates),
        vector=tuple(float(value) for value in vector),
    )
