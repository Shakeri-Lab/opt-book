"""Sub-Gaussian diagnostics introduced with C05."""

from __future__ import annotations

from collections.abc import Iterable

import numpy as np


def subgaussian_max_threshold(
    count: int,
    failure_probability: float,
    *,
    proxy_scale: float = 1.0,
) -> float:
    """Return the union-bound threshold for ``count`` sub-Gaussian variables."""

    if count < 1:
        raise ValueError("count must be positive")
    if not 0 < failure_probability < 1:
        raise ValueError("failure_probability must lie in (0, 1)")
    if proxy_scale <= 0:
        raise ValueError("proxy_scale must be positive")
    return float(
        proxy_scale
        * np.sqrt(2.0 * np.log(2.0 * count / failure_probability))
    )


def standard_normal_maxima(
    counts: Iterable[int],
    *,
    seed: int,
) -> dict[int, float]:
    """Draw one independent standard-normal vector for each requested count."""

    resolved = tuple(int(count) for count in counts)
    if not resolved or any(count < 1 for count in resolved):
        raise ValueError("counts must be a nonempty positive sequence")
    streams = np.random.SeedSequence(seed).spawn(len(resolved))
    maxima = {}
    for count, stream in zip(resolved, streams, strict=True):
        rng = np.random.default_rng(stream)
        maxima[count] = float(np.max(np.abs(rng.standard_normal(count))))
    return maxima


def rademacher_projection_trials(
    coefficients: Iterable[float],
    *,
    trials: int,
    seed: int,
    chunk_size: int = 2048,
) -> np.ndarray:
    """Sample sums ``sum_j coefficients[j] * epsilon[j]`` with signs ±1."""

    weights = np.asarray(tuple(coefficients), dtype=np.float64)
    if weights.ndim != 1 or weights.size == 0:
        raise ValueError("coefficients must be a nonempty one-dimensional sequence")
    if trials < 1 or chunk_size < 1:
        raise ValueError("trials and chunk_size must be positive")
    rng = np.random.default_rng(seed)
    samples = np.empty(trials, dtype=np.float64)
    for start in range(0, trials, chunk_size):
        stop = min(start + chunk_size, trials)
        bits = rng.integers(
            0,
            2,
            size=(stop - start, weights.size),
            dtype=np.int8,
        )
        signs = 2 * bits - 1
        samples[start:stop] = signs @ weights
    return samples


def empirical_tail_profile(
    samples: Iterable[float],
    thresholds: Iterable[float],
) -> dict[float, float]:
    """Estimate two-sided tail probabilities with denominator ``len(samples)``."""

    values = np.asarray(tuple(samples), dtype=np.float64)
    levels = np.asarray(tuple(thresholds), dtype=np.float64)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("samples must be a nonempty one-dimensional sequence")
    if levels.ndim != 1 or levels.size == 0 or np.any(levels < 0):
        raise ValueError("thresholds must be a nonempty nonnegative sequence")
    magnitudes = np.abs(values)
    return {
        float(level): float(np.mean(magnitudes >= level))
        for level in levels
    }


def moment_growth_profile(
    samples: Iterable[float],
    orders: Iterable[int],
) -> dict[int, float]:
    """Estimate ``||X||_p / sqrt(p)`` for declared positive moment orders."""

    values = np.asarray(tuple(samples), dtype=np.float64)
    resolved_orders = tuple(int(order) for order in orders)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("samples must be a nonempty one-dimensional sequence")
    if not resolved_orders or any(order < 1 for order in resolved_orders):
        raise ValueError("orders must be a nonempty positive sequence")
    magnitudes = np.abs(values)
    return {
        order: float(np.mean(magnitudes**order) ** (1.0 / order) / np.sqrt(order))
        for order in resolved_orders
    }
