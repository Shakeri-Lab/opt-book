"""Diagnostic harness for *Deep Learning: Making It Trainable*."""

from .precision import (
    QuantizationResult,
    UpdateTrace,
    float_contract,
    local_spacing,
    repeated_update,
    stochastic_update_trials,
    symmetric_quantize,
)
from .optimization import (
    NoisyQuadraticSummary,
    QuadraticTrace,
    classify_mode_factors,
    quadratic_spectrum,
    quadratic_trace,
    scalar_noisy_quadratic_trials,
)
from .probability import (
    empirical_tail_profile,
    moment_growth_profile,
    rademacher_projection_trials,
    standard_normal_maxima,
    subgaussian_max_threshold,
)
from .streaming import (
    MomentState,
    comparison_audit,
    merge_moments,
    naive_moments,
    observation_ledger,
    stable_online_moments,
)

__all__ = [
    "MomentState",
    "NoisyQuadraticSummary",
    "QuantizationResult",
    "QuadraticTrace",
    "UpdateTrace",
    "comparison_audit",
    "classify_mode_factors",
    "empirical_tail_profile",
    "float_contract",
    "local_spacing",
    "merge_moments",
    "moment_growth_profile",
    "naive_moments",
    "observation_ledger",
    "quadratic_spectrum",
    "quadratic_trace",
    "rademacher_projection_trials",
    "repeated_update",
    "stable_online_moments",
    "scalar_noisy_quadratic_trials",
    "standard_normal_maxima",
    "stochastic_update_trials",
    "symmetric_quantize",
    "subgaussian_max_threshold",
]

__version__ = "0.5.0"
