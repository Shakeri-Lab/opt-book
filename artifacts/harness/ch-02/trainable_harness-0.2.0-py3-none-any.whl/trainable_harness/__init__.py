"""Diagnostic harness for *Deep Learning: Making It Trainable*."""

from .streaming import (
    MomentState,
    comparison_audit,
    merge_moments,
    naive_moments,
    observation_ledger,
    stable_online_moments,
)

__all__ = [
    "MomentState",
    "comparison_audit",
    "merge_moments",
    "naive_moments",
    "observation_ledger",
    "stable_online_moments",
]

__version__ = "0.2.0"
