"""Diagnostic harness for *Deep Learning: Making It Trainable*."""

from .precision import (
    QuantizationResult,
    UpdateTrace,
    float_contract,
    local_spacing,
    repeated_update,
    stochastic_update_trials,
    symmetric_quantize,
)
from .streaming import (
    MomentState,
    comparison_audit,
    merge_moments,
    naive_moments,
    observation_ledger,
    stable_online_moments,
)

__all__ = [
    "MomentState",
    "QuantizationResult",
    "UpdateTrace",
    "comparison_audit",
    "float_contract",
    "local_spacing",
    "merge_moments",
    "naive_moments",
    "observation_ledger",
    "repeated_update",
    "stable_online_moments",
    "stochastic_update_trials",
    "symmetric_quantize",
]

__version__ = "0.3.0"
